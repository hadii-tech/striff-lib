function main(args, out, res) {
  return { args: args };
}
