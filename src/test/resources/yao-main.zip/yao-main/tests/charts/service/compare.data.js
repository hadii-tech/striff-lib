function main(args, out, res) {
  console.log(args, out, res);
  return out;
}
