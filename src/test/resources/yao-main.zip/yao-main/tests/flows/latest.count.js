function main(args, out, res) {
  return {
    args: args,
    plugin: res.github.name,
  };
}
