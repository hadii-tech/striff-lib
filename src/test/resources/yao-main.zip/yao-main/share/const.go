package share

// VERSION 版本号
const VERSION = "0.9.2"

// BUILDIN 打包应用合成一个制品
const BUILDIN = false

// BUILDNAME 制品名称
const BUILDNAME = "yao"
