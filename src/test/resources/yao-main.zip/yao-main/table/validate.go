package table

// Validate 校验表格格式
// func (table Table) Validate() error {
// 	return nil
// }
